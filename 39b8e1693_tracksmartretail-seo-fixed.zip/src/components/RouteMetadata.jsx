import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const SITE_URL = 'https://tracksmartretail.com';
const SITE_NAME = 'TrackSmart Retail';
const DEFAULT_DESCRIPTION =
  "TrackSmart Retail aide les épiceries, mini-marchés et commerces de proximité à suivre les dates de péremption, réduire les pertes et gérer les stocks.";
const DEFAULT_IMAGE = `${SITE_URL}/og-image.svg`;

const publicPages = {
  '/': {
    title: 'TrackSmart Retail — Suivi des dates de péremption pour épiceries',
    description: DEFAULT_DESCRIPTION,
  },
  '/about': {
    title: 'À propos — TrackSmart Retail',
    description:
      "Découvrez la mission de TrackSmart Retail : aider les commerçants à réduire le gaspillage alimentaire et mieux gérer leurs stocks.",
  },
  '/contact': {
    title: 'Contact — TrackSmart Retail',
    description:
      "Contactez TrackSmart Retail pour une question, une démonstration ou un accompagnement sur la gestion des stocks et des DLC.",
  },
  '/demo': {
    title: 'Démo — TrackSmart Retail',
    description:
      "Essayez une démonstration de TrackSmart Retail avec suivi des stocks, alertes DLC, rapports, commandes et documents.",
  },
};

const setMeta = (selector, attr, value) => {
  let element = document.head.querySelector(selector);

  if (!element) {
    element = document.createElement('meta');
    const match = selector.match(/\[(name|property)="([^"]+)"\]/);
    if (match) {
      element.setAttribute(match[1], match[2]);
    }
    document.head.appendChild(element);
  }

  element.setAttribute(attr, value);
};

export default function RouteMetadata() {
  const location = useLocation();

  useEffect(() => {
    const path = location.pathname.replace(/\/$/, '') || '/';
    const page = publicPages[path];
    const isIndexable = Boolean(page);
    const title = page?.title || SITE_NAME;
    const description = page?.description || DEFAULT_DESCRIPTION;
    const canonical = `${SITE_URL}${path === '/' ? '/' : path}`;
    const robots = isIndexable ? 'index, follow' : 'noindex, nofollow';

    document.title = title;
    setMeta('meta[name="description"]', 'content', description);
    setMeta('meta[name="robots"]', 'content', robots);
    setMeta('meta[property="og:title"]', 'content', title);
    setMeta('meta[property="og:description"]', 'content', description);
    setMeta('meta[property="og:url"]', 'content', canonical);
    setMeta('meta[property="og:image"]', 'content', DEFAULT_IMAGE);
    setMeta('meta[name="twitter:title"]', 'content', title);
    setMeta('meta[name="twitter:description"]', 'content', description);
    setMeta('meta[name="twitter:image"]', 'content', DEFAULT_IMAGE);

    let canonicalLink = document.head.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonical);
  }, [location.pathname]);

  return null;
}
